package Contact;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
class ContactTest {
Contact contact = new Contact("1", "Barbara", "Willowbird", "123456789", "123 Lyon Ln. 123456789");
 @Test
 void testGetId() {
 assertEquals("1", contact.getId());
 }
 private void assertEquals(String string, String id) {
	// TODO Auto-generated method stub
	
}
@Test
 void testGetFirstName() {
 assertEquals("Barbara", contact.getFirstName());
 }
 @Test
 void testGetNumber() {
 assertEquals("123456789", contact.getNumber());
 }
 @Test
 void testGetAddress() {
 assertEquals("123 Lyon Ln. 123456789", contact.getAddress());
 }
 @Test
 void testToString() {
 assertEquals("Contact [id = 1, firstName = Barbara, lastName = Willowbird,Number = 123456789, address = 123 Lyon Ln. 123456789]", contact.toString());
 }
 @Test
 void testCreateContactWithInvalidId() {
 assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Layla", "Jackson", "12345678789", "123 85th"));
 }
 @Test
 void testCreateContactWithValidData() {
 Contact contact = new Contact("2", "Layla", "Jackson", "123456789", "123 Bailey Ave");
 assertNotNull(contact);
 assertEquals("2", contact.getId());
 assertEquals("Layla", contact.getFirstName());
 assertEquals("Jackson", contact.getLastName());
 assertEquals("123456789", contact.getNumber());
 assertEquals("123 Bailey Ave", contact.getAddress());
 }
 @Test
 void testCreateContactWithInvalidData() {
 Assertions.assertThrows(IllegalArgumentException.class, () ->
 new Contact("3", "Invalid", "Data", "InvalidNumber","InvalidAddress"));
 }
 @Test
 void testCreateContactWithInvalidFirstName() {
 Assertions.assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Barrrbara", "Pineapple", "123456789", "123 Bailey Ave"));
 }
 @Test
 void testCreateContactWithInvalidLastName() {
 Assertions.assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Layla", "Jack", "123456789", "123 Bailey Ave"));
 }
 @Test
 void testCreateContactWithInvalidNumber() {
 Assertions.assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Layla", "Jackson", "23131343245432", "123 Baily Ave"));
 }
 @Test
 void testCreateContactWithInvalidAddress() {
 Assertions.assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Layla", "Jackson", "123456789", "321 JasonSt"));
 }
 @Test
 void testCreateContactWithTooLongNumber() {
 Assertions.assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Layla", "Jackson", "12345678901", "123 Bailey Ave"));
 }
 @Test
 void testCreateContactWithShortNumber() {
 Assertions.assertThrows(IllegalArgumentException.class, () -> new
Contact("2", "Layla", "Jackson", "12", "123 Bailey Ave"));
 }
}
